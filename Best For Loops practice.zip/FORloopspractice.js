let tables = [1,2,3,4,5,6,7,8,9,10];

let table1 = tables[0];

for(table1 = 1; table1 <= 10; table1 +=1){
    console.log(table1 + " ")
}

let table2 = tables[1];

for(table2 = 2; table2 <= 20; table2 +=2){
    console.log(table2)
}

let table3 = tables[2];

for(table3 = 3; table3 <= 30; table3 +=3){
    console.log(table3)
}

let table4 = tables[3];

for(table4 = 4; table4 <= 40; table4 +=4){
    console.log(table4)
}

let table5 = tables[4];

for(table5 = 5; table5 <= 50; table5 +=5){
    console.log(table5)
}

let table6 = tables[5];

for(table6 = 6; table6 <= 60; table6 +=6){
    console.log(table6)
}

let table7 = tables[6];

for(table7 = 7; table7 <= 70; table7 +=7){
    console.log(table7)
}

let table8 = tables[7];

for(table5 = 8; table5 <= 80; table5 +=8){
    console.log(table8)
}

let table9 = tables[8];

for(table9 = 9; table9 <= 90; table5 +=9){
    console.log(table9)
}

let table10 = tables[9];

for(table10 = 10; table10 <= 100; table10 +=10){
    console.log(table10)
}